GODMODE V4 / SIGNAL LAB — DESIRE VOICE CLIPS

Upload this ZIP file into the GitHub folder:
static/desire_audio/

The updated GODMODE server will extract the MP3 clips from this ZIP the first time an audio clip is requested. Keep the ZIP in static/desire_audio/ after uploading.

The files include activation, superior signal, strength, five-second countdown, twenty-second entry window, below-threshold, cancelled, CALL, PUT, scanning, fakeout warning, signal locked, and standby announcements.
